using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace XiDeAI_Pro.Services
{
    public class OmniScoutItem
    {
        public string source { get; set; } = "";
        public string title { get; set; } = "";
        public string url { get; set; } = "";
        public string published { get; set; } = "";
        public int score { get; set; }
    }

    public class OmniScoutData
    {
        public string timestamp { get; set; } = "";
        public List<OmniScoutItem> trends { get; set; } = new List<OmniScoutItem>();
        public List<OmniScoutItem> tech_news { get; set; } = new List<OmniScoutItem>();
        public List<OmniScoutItem> world_news { get; set; } = new List<OmniScoutItem>();
        public List<OmniScoutItem> law_news { get; set; } = new List<OmniScoutItem>();
        public List<OmniScoutItem> science_news { get; set; } = new List<OmniScoutItem>();
        public List<OmniScoutItem> defense_news { get; set; } = new List<OmniScoutItem>();
        public List<OmniScoutItem> life_inventions { get; set; } = new List<OmniScoutItem>();
        public List<OmniScoutItem> lifestyle_news { get; set; } = new List<OmniScoutItem>();
        public List<OmniScoutItem> auto_moto { get; set; } = new List<OmniScoutItem>(); // Added
        public List<OmniScoutItem> sports_news { get; set; } = new List<OmniScoutItem>(); // Added
        public string error { get; set; } = "";
    }

    public class OmniScoutService
    {
        private readonly string _scriptsPath;
        private readonly GeminiService _gemini;
        private readonly WisdomService _wisdom;
        private readonly ThreadService? _threadSvc; // Added
        private readonly Action<string> _logger;
        private OmniScoutData _data = new OmniScoutData();
        public string LastReport { get; private set; } = "Henüz Omni-Scout analizi yapılmadı.";


        public OmniScoutService(string scriptsPath, GeminiService gemini, WisdomService wisdom, ThreadService? threadSvc = null, Action<string>? logger = null)
        {
            _scriptsPath = scriptsPath;
            _gemini = gemini;
            _wisdom = wisdom;
            _threadSvc = threadSvc;
            _logger = logger ?? (_ => { });
        }

        private void Log(string msg) => _logger?.Invoke(msg);


        public async Task RefreshAsync()
        {
            Log("🌍 [HIVE INTEL] Nirvana Modu: Otomotiv ve Spor verileri taranıyor...");
            
            try
            {
                string scriptFile = Path.Combine(_scriptsPath, "omni_scout.py");
                if (!File.Exists(scriptFile))
                {
                     Log("❌ [HIVE INTEL] Script bulunamadı: " + scriptFile);
                     return;
                }

                var psi = new ProcessStartInfo
                {
                    FileName = "python",
                    Arguments = $"\"{scriptFile}\"",
                    RedirectStandardOutput = true,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    StandardOutputEncoding = Encoding.UTF8
                };

                using var process = Process.Start(psi);
                if (process == null) return;

                // v3.7: Added timeout to prevent infinite hang if scraper stuck
                var outputTask = process.StandardOutput.ReadToEndAsync();
                
                // Wait with 90s timeout
                if (await Task.WhenAny(outputTask, Task.Delay(90000)) == outputTask)
                {
                    string output = await outputTask;
                    await process.WaitForExitAsync();

                    if (!string.IsNullOrEmpty(output))
                    {
                        var result = JsonSerializer.Deserialize<OmniScoutData>(output);
                        if (result != null)
                        {
                            _data = result;
                            Log($"✅ [HIVE INTEL] Nirvana Verisi Hazır. Araçlar: {_data.auto_moto.Count}, Spor: {_data.sports_news.Count}");
                        }
                    }
                }
                else
                {
                    Log("⚠️ [HIVE INTEL] Omni-Scout taraması zaman aşımına uğradı (90s).");
                    try { process.Kill(); } catch { }
                }
            }
            catch (Exception ex)
            {
                Log($"❌ [HIVE INTEL] Hata: {ex.Message}");
            }
        }

        public async Task<string> GenerateGlobalInsightAsync()
        {
            if (_data.trends.Count == 0 && _data.tech_news.Count == 0 && _data.world_news.Count == 0) return "İstihbarat verisi yok.";

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("📡 HIVE INTEL - OMNIPOTENT GLOBAL SENTEZ (CORTEX PHASE 4)");
            sb.AppendLine($"📅 {DateTime.Now:dd.MM.yyyy HH:mm}");
            sb.AppendLine();
            
            sb.AppendLine("🏁 OTOMOTİV & SPOR & YAŞAM (Popüler Kültür):");
            _data.auto_moto.Take(5).ToList().ForEach(x => sb.AppendLine($"- {x.title}"));
            _data.sports_news.Take(5).ToList().ForEach(x => sb.AppendLine($"- {x.title}"));
            _data.lifestyle_news.Take(5).ToList().ForEach(x => sb.AppendLine($"- {x.title}"));

            sb.AppendLine();
            sb.AppendLine("🛡️ JEOPOLİTİK, HUKUK VE BİLİM (Sert Güç):");
            _data.defense_news.Take(5).ToList().ForEach(x => sb.AppendLine($"- {x.title}"));
            _data.law_news.Take(5).ToList().ForEach(x => sb.AppendLine($"- {x.title}"));
            _data.science_news.Take(5).ToList().ForEach(x => sb.AppendLine($"- {x.title}"));

            string prompt = "### SENARYO: Sen CORTEX (Merkezi Yapay Zeka Beyni) birimisin. Görevin: Dünyayı sarsmak ve kazanç sağlamak.\n\n" +
                            "Aşağıdaki verileri 3 kritere göre işle:\n\n" +
                            "1. [VIRAL_ENGINE]: Öyle bir içerik kurgusu yap ki (X Thread, Reel planı vb.), insanlar bu 'farklı bakış açısını' gördüğünde şok olsun. Gündemi biz belirleyelim.\n" +
                            "2. [SIGNAL_BRAIN]: Veriler arasından para edecek bir 'Sinyal' çıkar. (Örn: Bir şirketin hissesi, bir kripto para, bir bahis tahmini veya bir emtia).\n" +
                            "3. [PREDICTIVE_ACTION]: 2 adım sonrasını söyle. Dominonun son taşı nereye düşecek?\n\n" +
                            $"VERI HAVUZU:\n{sb.ToString()}\n\n" +
                            "YANIT FORMATI:\n" +
                            "🚀 VIRAL KURGU: (Gündem yaratacak başlık ve yapı)\n" +
                            "💰 OPERASYONEL SİNYAL: (Harekete geçilecek finansal/bahis sinyali)\n" +
                            "🔮 DOMİNO ETKİSİ: (Gelecek öngörüsü)";

            Log("🧠 [CORTEX LEVEL 4] Viral ve Sinyal sentezi başlatılıyor...");
            string blueprint = await _gemini.GenerateGenericContent(prompt);
            LastReport = blueprint;

            if (string.IsNullOrEmpty(blueprint))
            {
                return $"Sentez başarısız. (Hata: {_gemini.LastError})";
            }

            // Nirvana Engine: Generate the actual X Thread and Signal from the blueprint in PARALLEL
            Log("🚀 [CORTEX] Alt süreçler (Thread + Signal) paralel olarak başlatıldı...");
            var viralTask = GenerateViralThreadAsync(blueprint);
            var signalTask = GenerateActionableSignalAsync(blueprint);

            await Task.WhenAll(viralTask, signalTask);

            string viralThread = await viralTask;
            string operationalSignal = await signalTask;

            // Save to Wisdom with specific tags
            var wisdomItem = new WisdomItem
            {
                Category = "CORTEX-SIGNAL",
                Title = $"HIVE INTEL Nirvana Raporu ({DateTime.Now:dd.MM})",
                Summary = $"--- [CORTEX ANALİZ] ---\n{blueprint}\n\n" +
                          $"--- [🚀 VIRAL X DRAFT] ---\n{viralThread}\n\n" +
                          $"--- [💰 SIGNAL] ---\n{operationalSignal}",
                SourceAuthor = "CORTEX Nirvana Core",
                SourceUrl = "Internal/NirvanaEngine",
                Priority = "URGENT",
                ActionItem = "Viral X Thread taslağını paylaş ve operasyonel sinyali doğrula."
            };
            
            _wisdom?.AddInsight(wisdomItem);
            Log("🧠 [CORTEX->WISDOM] URGENT Nirvana raporu (Viral + Sinyal) kaydedildi.");

            return blueprint;
        }

        public async Task<string> GenerateViralThreadAsync(string blueprint)
        {
            Log("🚀 [NIRVANA-X] Viral Thread kurgusu başlatılıyor...");
            
            StringBuilder sb = new StringBuilder();
            _data.auto_moto.Take(3).ToList().ForEach(x => sb.AppendLine($"- {x.title} ({x.source})"));
            _data.sports_news.Take(3).ToList().ForEach(x => sb.AppendLine($"- {x.title} ({x.source})"));
            _data.life_inventions.Take(2).ToList().ForEach(x => sb.AppendLine($"- {x.title} ({x.source})"));

            var promptManager = new PromptManager();
            string prompt = promptManager.GetViralXThreadPrompt(blueprint, sb.ToString());

            string threadContent = await _gemini.GenerateGenericContent(prompt) ?? "Thread üretilemedi.";
            Log("✅ [NIRVANA-X] Viral Thread taslağı hazır.");
            return threadContent;
        }

        public async Task<string> GenerateActionableSignalAsync(string blueprint)
        {
            Log("💰 [SIGNAL-HUNTER] Operasyonel sinyal ayıklanıyor...");
            
            var promptManager = new PromptManager();
            string prompt = promptManager.GetActionableSignalPrompt(blueprint);

            string signalContent = await _gemini.GenerateGenericContent(prompt) ?? "Sinyal üretilemedi.";
            Log("✅ [SIGNAL-HUNTER] Net talimat hazır.");
            return signalContent;
        }
    }
}
