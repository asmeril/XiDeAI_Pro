using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace XiDeAI_Pro.Services
{
    public class ApexPaper
    {
        public string id { get; set; } = "";
        public string title { get; set; } = "";
        public string summary { get; set; } = "";
        public int upvotes { get; set; }
        public string publishedAt { get; set; } = "";
        public string link { get; set; } = "";
    }

    public class ApexRepo
    {
        public string name { get; set; } = "";
        public string full_name { get; set; } = "";
        public string description { get; set; } = "";
        public int stars { get; set; }
        public int forks { get; set; }
        public string url { get; set; } = "";
        public string owner { get; set; } = "";
    }

    public class ApexResearchData
    {
        public DateTime LastUpdate { get; set; }
        public List<ApexPaper> Papers { get; set; } = new List<ApexPaper>();
        public List<ApexRepo> Repos { get; set; } = new List<ApexRepo>();
    }

    public class ApexService
    {
        private readonly string _scriptsPath;
        private readonly string _storagePath;
        private readonly GeminiService _gemini;
        private readonly WisdomService _wisdom; // Added
        private readonly Action<string> _logger;
        private ApexResearchData _data = new ApexResearchData();

        public ApexService(string scriptsPath, GeminiService gemini, WisdomService wisdom, Action<string>? logger = null) // Modified
        {
            _scriptsPath = scriptsPath;
            _gemini = gemini;
            _wisdom = wisdom; // Added
            _logger = logger ?? (_ => { });
            
            string appData = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "XiDeAI");
            _storagePath = Path.Combine(appData, "Apex_Research.json");
            
            LoadData();
        }

        private void Log(string msg) => _logger?.Invoke(msg);

        public async Task RefreshAllAsync(string topic = "AI")
        {
            Log($"🚀 [APEX] Ar-Ge verileri yenileniyor... Konu: {topic}");
            
            var papersTask = FetchFromPython<List<ApexPaper>>("papers.py", topic);
            var reposTask = FetchFromPython<List<ApexRepo>>("repos.py", topic);

            await Task.WhenAll(papersTask, reposTask);

            _data.Papers = await papersTask;
            _data.Repos = await reposTask;
            _data.LastUpdate = DateTime.Now;

            SaveData();
            Log($"✅ [APEX] Yenileme tamamlandı. {_data.Papers.Count} makale, {_data.Repos.Count} proje bulundu ({topic}).");
        }

        private async Task<T> FetchFromPython<T>(string scriptName, string topic) where T : new()
        {
            try
            {
                string scriptFile = Path.Combine(_scriptsPath, scriptName);
                if (!File.Exists(scriptFile)) return new T();

                // Build Arguments with Topic
                string args = $"\"{scriptFile}\" --topic \"{topic}\"";

                var psi = new ProcessStartInfo
                {
                    FileName = "python",
                    Arguments = args,
                    RedirectStandardOutput = true,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    StandardOutputEncoding = Encoding.UTF8
                };
                
                // v3.7.3: Robust UTF-8 communication
                psi.EnvironmentVariables["PYTHONIOENCODING"] = "UTF-8";

                using var process = Process.Start(psi);
                if (process == null) return new T();

                // v3.7: Added timeout to prevent infinite hang
                var outputTask = process.StandardOutput.ReadToEndAsync();
                
                if (await Task.WhenAny(outputTask, Task.Delay(90000)) == outputTask)
                {
                    string output = await outputTask;
                    await process.WaitForExitAsync();

                    return JsonSerializer.Deserialize<T>(output) ?? new T();
                }
                else
                {
                    Log($"⚠️ [APEX] {scriptName} zaman aşımına uğradı (90s).");
                    try { process.Kill(); } catch { }
                    return new T();
                }
            }
            catch (Exception ex)
            {
                Log($"❌ [APEX] {scriptName} hatası: {ex.Message}");
                return new T();
            }
        }

        public ApexResearchData GetData() => _data;

        public async Task<string> GenerateArGeReportAsync()
        {
            if (_data.Papers.Count == 0 && _data.Repos.Count == 0)
                return "Henüz Ar-Ge verisi toplanmadı.";

            Log("🤖 [APEX] Otonom Ar-Ge raporu oluşturuluyor...");
            
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("📌 GÜNLÜK AR-GE ANALİZ RAPORU");
            sb.AppendLine($"📅 Tarih: {DateTime.Now:dd.MM.yyyy HH:mm}");
            sb.AppendLine();
            
            sb.AppendLine("🔬 GÜNÜN ÖNE ÇIKAN MAKALELERİ (HuggingFace):");
            foreach (var p in _data.Papers.GetRange(0, Math.Min(5, _data.Papers.Count)))
            {
                sb.AppendLine($"• {p.title} ({p.upvotes} Upvotes)");
                sb.AppendLine($"  Link: {p.link}");
                if (!string.IsNullOrEmpty(p.summary)) sb.AppendLine($"  Özet: {p.summary}");
                sb.AppendLine();
            }
            
            sb.AppendLine("💻 GÜNÜN TREND PROJELERİ (GitHub):");
            foreach (var r in _data.Repos.GetRange(0, Math.Min(5, _data.Repos.Count)))
            {
                sb.AppendLine($"• {r.full_name} ({r.stars} Stars)");
                sb.AppendLine($"  Link: {r.url}");
                if (!string.IsNullOrEmpty(r.description)) sb.AppendLine($"  Açıklama: {r.description}");
                sb.AppendLine();
            }

            string prompt = $"Aşağıdaki Ar-Ge verilerini (makaleler ve yazılım projeleri) analiz et. \n" +
                           $"Bunların finansal teknolojiler, otonom sistemler veya genel yapay zeka gelişimi açısından stratejik önemini 3-4 maddede profesyonel bir dille açıkla. \n" +
                           $"En heyecan verici gördüğün bir tanesini özellikle vurgula ve 'Günün Keşfi' olarak işaretle. \n\n" +
                           $"VERİLER:\n{sb.ToString()}";

            string analysis = await _gemini.GenerateGenericContent(prompt, XiDeAI_Pro.Services.AI.TaskType.ArGeAnalysis);

            if (string.IsNullOrEmpty(analysis))
            {
                return $"Analiz oluşturulamadı. (Hata: {_gemini.LastError})";
            }

            // Save to Wisdom (Memory)
            if (_wisdom != null)
            {
                var wisdomItem = new WisdomItem
                {
                    Category = "TECH", 
                    Title = $"Apex Ar-Ge Raporu ({DateTime.Now:dd.MM.yyyy})",
                    Summary = analysis + "\n\n" + sb.ToString(), 
                    SourceAuthor = "Apex Engine (System)",
                    SourceUrl = "Internal/Apex",
                    Priority = "HIGH",
                    ActionItem = "Günün keşfini incele ve uygunsa prototip oluştur."
                };
                
                _wisdom.AddInsight(wisdomItem);
                Log("🧠 [APEX->WISDOM] Ar-Ge raporu bilgelik havuzuna ('TECH') kaydedildi.");
            }

            return analysis;
        }

        private void SaveData()
        {
            try
            {
                string json = JsonSerializer.Serialize(_data, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(_storagePath, json);
            }
            catch (Exception ex) { Log($"❌ [APEX] Kayıt hatası: {ex.Message}"); }
        }

        private void LoadData()
        {
            try
            {
                if (File.Exists(_storagePath))
                {
                    string json = File.ReadAllText(_storagePath);
                    _data = JsonSerializer.Deserialize<ApexResearchData>(json) ?? new ApexResearchData();
                }
            }
            catch { _data = new ApexResearchData(); }
        }
    }
}
