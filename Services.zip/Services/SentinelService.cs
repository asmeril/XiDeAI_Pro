using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using System.Collections.Concurrent;
using System.Threading;

namespace XiDeAI_Pro.Services
{
    public enum SentinelContext
    {
        HIVE,
        Signal,
        Manual,
        Guru
    }

    public class SentinelWatchItem
    {
        public string Url { get; set; } = "";
        public string SourceId { get; set; } = "";
        public SentinelContext Context { get; set; } = SentinelContext.HIVE;
        public DateTime AddedAt { get; set; } = DateTime.Now;
    }

    public class ReplyAnalysis
    {
        public int Id { get; set; } // Tracking ID for approving
        public string Handle { get; set; } = "";
        public string Text { get; set; } = "";
        public string Url { get; set; } = "";
        public string Category { get; set; } = "DESTEK"; // DESTEK, SORU, ELESTIRI, SPAM, TALEP
        public string RequestedSymbol { get; set; } = ""; // E.g. $BTC
        public string AiProposal { get; set; } = "";
        public DateTime DetectedAt { get; set; } = DateTime.Now;
        public SentinelContext Context { get; set; } = SentinelContext.HIVE;
    }

    public class SentinelService
    {
        private readonly SocialIntelService _social;
        private readonly GeminiService _gemini;
        private readonly ConcurrentDictionary<string, SentinelWatchItem> _watchList = new ConcurrentDictionary<string, SentinelWatchItem>(); // URL -> Item
        private readonly ConcurrentDictionary<string, HashSet<string>> _processedReplies = new ConcurrentDictionary<string, HashSet<string>>(); // URL -> Set of reply URLs
        private readonly ConcurrentDictionary<string, HashSet<string>> _thankedRetweeters = new ConcurrentDictionary<string, HashSet<string>>(); // TweetURL -> Set of handles
        private int _replyIdCounter = 0;
        
        public event Action<string, ReplyAnalysis>? OnReplyDetected; // SourceId, Analysis

        public SentinelService(SocialIntelService social, GeminiService gemini)
        {
            _social = social;
            _gemini = gemini;
            _analysisHistory = new Dictionary<string, List<ReplyAnalysis>>();
        }





        private Dictionary<string, List<ReplyAnalysis>> _analysisHistory; // Url -> List of Analysis

        public string GetEngagementReport(string sourceOpId)
        {
            var relevantItems = _watchList.Values.Where(v => v.SourceId == sourceOpId).ToList();

            int totalReplies = 0;
            int totalPositive = 0;
            var feedbacks = new List<string>();

            foreach (var item in relevantItems)
            {
                if (_analysisHistory.ContainsKey(item.Url))
                {
                    var analyses = _analysisHistory[item.Url];
                    totalReplies += analyses.Count;
                    totalPositive += analyses.Count(a => a.Category == "DESTEK" || a.Category == "TALEP");
                    feedbacks.AddRange(analyses.Select(a => $"- {a.Handle}: {a.AiProposal}"));
                }
            }

            if (totalReplies == 0) return "Henüz etkileşim tespit edilmedi.";

            double sentiment = (double)totalPositive / totalReplies * 100;
            return $"📊 TOPLAM ETKİLEŞİM: {totalReplies}\n" +
                   $"😊 DUYGU DURUMU: %{sentiment:F1} Pozitif\n\n" +
                   "💡 ÖNE ÇIKAN GERİ BİLDİRİMLER:\n" +
                   string.Join("\n", feedbacks.Take(5));
        }

        public void AddToWatchList(string tweetUrl, string sourceId, SentinelContext context = SentinelContext.HIVE)
        {
            if (string.IsNullOrEmpty(tweetUrl)) return;
            
            var item = new SentinelWatchItem { 
                Url = tweetUrl, 
                SourceId = sourceId, 
                Context = context 
            };
            
            _watchList[tweetUrl] = item;
            
            if (!_processedReplies.ContainsKey(tweetUrl))
                _processedReplies[tweetUrl] = new HashSet<string>();
                
            if (!_thankedRetweeters.ContainsKey(tweetUrl))
                _thankedRetweeters[tweetUrl] = new HashSet<string>();
        }

        public async Task ProcessAllWatchedTweets()
        {
            foreach (var item in _watchList.Values)
            {
                await ProcessTweetReplies(item.Url, item.SourceId, item.Context);
                await ProcessTweetRetweets(item.Url, item.SourceId, item.Context);
            }
        }

        private async Task ProcessTweetReplies(string tweetUrl, string sourceId, SentinelContext context)
        {
            try
            {
                var result = await _social.FetchReplies(tweetUrl);
                if (result == null || result.status != "success" || result.data == null) return;

                foreach (var reply in result.data)
                {
                    if (string.IsNullOrEmpty(reply.url)) continue;
                    
                    if (!_processedReplies[tweetUrl].Contains(reply.url))
                    {
                        // New reply detected!
                        var analysis = await AnalyzeReply(reply, tweetUrl, context);
                        _processedReplies[tweetUrl].Add(reply.url);
                        
                        OnReplyDetected?.Invoke(sourceId, analysis);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Sys($"[Sentinel] Reply izleme hatası ({tweetUrl}): {ex.Message}");
            }
        }

        private async Task ProcessTweetRetweets(string tweetUrl, string sourceId, SentinelContext context)
        {
            try
            {
                // Only for technical analyses or HIVE if active
                var result = await _social.FetchRetweeters(tweetUrl);
                if (result == null || result.status != "success" || result.data == null) return;

                foreach (var rt in result.data)
                {
                    if (string.IsNullOrEmpty(rt.handle)) continue;
                    
                    if (!_thankedRetweeters[tweetUrl].Contains(rt.handle))
                    {
                        // New Retweeter!
                        Logger.Twitter($"📢 [Sentinel] RT Tespit Edildi: {rt.handle}");
                        
                        // Auto-Reply "Thank You"
                        string thankMsg = $"{rt.handle} Analizimi ReTweetlediğiniz için Teşekkür Ederim 🙏📈";
                        
                        // v3.7.4: Variation to avoid spam filter
                        int rnd = new Random().Next(1, 4);
                        if (rnd == 2) thankMsg = $"{rt.handle} Desteğiniz ve RT için çok teşekkürler! Bol kazançlar hatasız analizler dilerim.";
                        if (rnd == 3) thankMsg = $"{rt.handle} Bu analizi paylaştığınız için teşekkürler, kitlelere ulaşması önemli.";

                        // We delay a bit to look human
                        await Task.Delay(1000 * new Random().Next(2, 5));
                        
                        var replyRes = await _social.ReplyAsync(tweetUrl, thankMsg);
                        
                        if (replyRes != null && replyRes.status == "success")
                        {
                            _thankedRetweeters[tweetUrl].Add(rt.handle);
                            Logger.Twitter($"✅ [Sentinel] {rt.handle} hesabına teşekkür iletildi.");
                        }
                        else
                        {
                            Logger.Twitter($"❌ [Sentinel] {rt.handle} hesabına teşekkür iletilemedi: {replyRes?.ErrorMessage}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                 Logger.Sys($"[Sentinel] RT izleme hatası ({tweetUrl}): {ex.Message}");
            }
        }

        private async Task<ReplyAnalysis> AnalyzeReply(SocialIntelReply reply, string parentUrl, SentinelContext context)
        {
            var analysis = new ReplyAnalysis
            {
                Id = Interlocked.Increment(ref _replyIdCounter),
                Handle = reply.handle,
                Text = reply.text,
                Url = reply.url,
                Context = context
            };

            try
            {
                string prompt = $@"
Aşağıdaki tweet cevabını analiz et ve bir yanıt önerisi hazırla.

KULLANICI: {reply.handle}
CEVAP: {reply.text}

GÖREV:
1. Sınıflandır: [DESTEK, SORU, ELESTIRI, SPAM, TALEP]
   - Eğer kullanıcı bir hisse, coin veya emtia analizi istiyorsa kategori 'TALEP' olmalıdır.
2. Sembol Tespiti: Eğer kategori 'TALEP' ise, istenen sembolü (örn: THYAO, $BTC, Altın) ayıkla.
3. Yanıt Önerisi: Profesyonel, bilgili ama samimi bir dille (Tevfik DİNÇER üslubuyla) kısa bir yanıt yaz.

YANIT FORMATI (Sadece JSON):
{{
  ""category"": ""..."",
  ""symbol"": ""..."",
  ""proposal"": ""...""
}}";

                string? aiJson = await _gemini.SendRequest(prompt);
                if (!string.IsNullOrEmpty(aiJson))
                {
                    // Clean JSON markers
                    aiJson = aiJson.Replace("```json", "").Replace("```", "").Trim();
                    using var doc = System.Text.Json.JsonDocument.Parse(aiJson);
                    if (doc.RootElement.TryGetProperty("category", out var cat)) analysis.Category = cat.GetString() ?? "DESTEK";
                    if (doc.RootElement.TryGetProperty("symbol", out var sym)) analysis.RequestedSymbol = sym.GetString() ?? "";
                    if (doc.RootElement.TryGetProperty("proposal", out var prop)) analysis.AiProposal = prop.GetString() ?? "";
                }
            }
            catch (Exception ex)
            {
                analysis.AiProposal = $"Analiz hatası: {ex.Message}";
            }

            // Store history
            if (!_analysisHistory.ContainsKey(parentUrl))
                _analysisHistory[parentUrl] = new List<ReplyAnalysis>();
            
            _analysisHistory[parentUrl].Add(analysis);

            return analysis;
        }

        public async Task<string> PerformDeepResearch(string topic)
        {
            Logger.Sys($"🕵️ [Sentinel] Derin Araştırma Başlatıldı: {topic}");
            
            string prompt = $@"
Aşağıdaki konu hakkında internette derinlemesine bir araştırma yap ve özet bir istihbarat raporu sun.
KONU: {topic}

RAPOR FORMATI:
- Kritik Bilgiler: (Madde madde)
- Doğruluk Durumu: (Eğer bir iddia ise)
- Operatör İçin Tavsiye: (Bu bilgiyle ne yapılmalı?)
";

            // We use ModelManager with TaskType.GeneralAnalysis for Perplexity/Search
            if (_gemini.ModelManager != null)
            {
                return await _gemini.ModelManager.SendRequest(XiDeAI_Pro.Services.AI.TaskType.GeneralAnalysis, prompt) ?? "Araştırma başarısız.";
            }

            return await _gemini.SendRequest(prompt) ?? "Araştırma başarısız.";
        }
    }
}
