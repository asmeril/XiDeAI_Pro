﻿using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;
using XiDeAI_Pro.Config;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading;
using System.IO;

namespace XiDeAI_Pro.Services
{
    public class GeminiService
    {
        private static readonly HttpClient client = new HttpClient() { Timeout = TimeSpan.FromSeconds(120) };
        private static readonly SemaphoreSlim _semaphore = new SemaphoreSlim(1, 1); // v3.5.2: Sequential AI Traffic Control
        private readonly PromptManager _prompts = new PromptManager();
        private readonly MemoryEngine _memory;
        private readonly StatsEngine _stats;
        public string LastError { get; private set; } = "";
        
        // Multi-Model Fallback Support
        public XiDeAI_Pro.Services.AI.ModelManager? ModelManager { get; set; }

        public GeminiService(MemoryEngine memory, StatsEngine stats)
        {
            _memory = memory;
            _stats = stats;
            
            // v3.0: SSL stability for older environments
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls13;
        }

        public async Task<string?> GenerateTweetContent(SignalData sig, string screenshotPath, string influencerCitations = "")
        {
            string context = _memory.GetSymbolContext(sig.Symbol);
            
            // Load indicator guide if exists
            string indicatorContext = "";
            try
            {
                string indicatorGuidePath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Config", "IndicatorGuide.md");
                if (System.IO.File.Exists(indicatorGuidePath))
                {
                    indicatorContext = System.IO.File.ReadAllText(indicatorGuidePath);
                    indicatorContext = $@"
=== GÖSTERGE REHBERİ ===
{indicatorContext}
=== GÖSTERGE REHBERİ SONU ===

";
                }
            }
            catch { /* Indicator guide optional */ }
            
            // Format score as fraction for AI context
            string scoreStr = $"{sig.Score}/{sig.MaxScore}";
            
            string prompt = _prompts.GetSignalAnalysisPrompt(
                sig.Symbol, 
                sig.Strategy, 
                scoreStr, 
                sig.Price.ToString("N2"), 
                indicatorContext, 
                sig.Period,
                influencerCitations);

            if (!string.IsNullOrEmpty(context))
            {
                prompt += "\n\n" + context;
            }

            string? result = null;
            
            // v3.0: Multimodal support for signals
            if (!string.IsNullOrEmpty(screenshotPath) && System.IO.File.Exists(screenshotPath))
            {
                byte[] imageBytes = System.IO.File.ReadAllBytes(screenshotPath);
                string imageBase64 = Convert.ToBase64String(imageBytes);
                result = await SendMultimodalRequest(prompt, imageBase64);
            }
            else
            {
                result = await SendRequest(prompt);
            }

            if (!string.IsNullOrEmpty(result))
            {
                _memory.StoreAnalysis(sig.Symbol, sig.Strategy, result);
            }
            return result;
        }

        // Legacy support (to be removed after full migration)
        public async Task<string?> GenerateTweetContent(string symbol, string price, string score, string strategy, string trendList)
        {
            return await GenerateTweetContent(new SignalData { Symbol = symbol, Price = decimal.Parse(price), Score = int.Parse(score), Strategy = strategy }, "");
        }

        public async Task<string?> GenerateMarketAnalysis(string symbol, string marketType)
        {
            string prompt = $@"Sen uzman bir finansal analist ve portföy yöneticisisin.
{symbol} ({marketType}) için Kapsamlı Teknik ve Temel Analiz hazırla.

--- ANALİZ PLANI ---

1. 🏢 **Temel Görünüm & Sektör:**
   (Şirketin/Varlığın hikayesi ne? Sektöründeki konumu, son haber akışları ve temel rasyoları nasıl?)

2. 📐 **Teknik Göstergeler:**
   (RSI, MACD, Hareketli Ortalamalar ve Hacim ne söylüyor?)

3. 🛡️ **Kritik Seviyeler:**
   • Destekler: [Seviyeler]
   • Dirençler: [Seviyeler]

4. 🌍 **Global & Benchmark:**
   ({(marketType == "KRİPTO" ? "Bitcoin dominansı" : marketType == "FOREX" ? "DXY endeksi" : "BIST100 endeksi")} ile korelasyonu nasıl?)

5. 🧠 **Yönetici Özeti:**
   (Kısa, orta ve uzun vade beklentin nedir?)

⚠️ _Yasal Uyarı: Yatırım tavsiyesi değildir._";

            return await SendRequest(prompt);
        }

        /// <summary>
        /// Generate market analysis WITH real-time price data from APIs
        /// </summary>
        public async Task<string?> GenerateMarketAnalysisWithPrice(string symbol, string marketType, string priceContext, string influencerCitations = "")
        {
            // Load indicator guide if exists
            string indicatorContext = "";
            try
            {
                string indicatorGuidePath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Config", "IndicatorGuide.md");
                if (System.IO.File.Exists(indicatorGuidePath))
                {
                    indicatorContext = System.IO.File.ReadAllText(indicatorGuidePath);
                    indicatorContext = $@"
=== GÖSTERGESİ REHBERI ===
{indicatorContext}
=== GÖSTERGE REHBERİ SONU ===

";
                }
            }
            catch { /* Indicator guide optional */ }

            string prompt = _prompts.GetDeepManualAnalysisPrompt(symbol, marketType, priceContext, indicatorContext, influencerCitations);

            return await SendRequest(prompt);
        }

        public async Task<string?> AnalyzeNewsImpact(string title, string source)
        {
            // v3.0: Editor Mode (Confidence Scoring)
            string prompt = _prompts.GetNewsEditorPrompt(title, source);

            if (ModelManager != null && ConfigManager.Current?.EnableMultiModel == true)
            {
                return await ModelManager.SendRequest(XiDeAI_Pro.Services.AI.TaskType.NewsAnalysis, prompt);
            }

            return await SendRequest(prompt);
        }

        /// <summary>
        /// Parse symbols, periods and the name of the scan/table from a Guru's screenshot table
        /// </summary>
        public async Task<(List<(string Symbol, string Period)> Items, string TableName)> ParseGuruTableFromImage(string imageUrl)
        {
            var results = new List<(string Symbol, string Period)>();
            string tableName = "Teknik Tarama Listesi";
            try
            {
                // Download image to temporary buffer for Gemini
                byte[] imageBytes = await client.GetByteArrayAsync(imageUrl);
                string imageBase64 = Convert.ToBase64String(imageBytes);

                string prompt = @"Bu bir borsa tarama sonuç tablosudur (Genellikle Efe HMA, Efelerin Efesi gibi başlıkları olur). 
Lütfen bu görseldeki tablodan 'Sembol' (hisse adı) ve 'Periyot' (15, 60, 180, 240, G vb.) sütunlarını oku.
Ayrıca görselin başlığından veya tablo isminden bu taramanın adını (Örn: 'EFE HMA', 'EFELERİN EFESİ STAR') tespit et.

Sadece şu JSON formatında döndür:
{
  ""TableName"": ""Tespit Edilen Tarama Adı"",
  ""Items"": [{""Symbol"": ""THYAO"", ""Period"": ""240""}, {""Symbol"": ""EBEBK"", ""Period"": ""180""}]
}

Eğer tablo/isim bulunamazsa TableName kısmına 'Teknik Tarama' yaz.";

                string? jsonResponse = await SendMultimodalRequest(prompt, imageBase64);
                if (!string.IsNullOrEmpty(jsonResponse))
                {
                    // Robust cleanup: extract JSON object from any surrounding text/markdown
                    int startIdx = jsonResponse.IndexOf('{');
                    int endIdx = jsonResponse.LastIndexOf('}');
                    if (startIdx >= 0 && endIdx > startIdx)
                    {
                        jsonResponse = jsonResponse.Substring(startIdx, endIdx - startIdx + 1);
                    }
                    else
                    {
                        // Fallback cleanup if strict braces aren't found (rare)
                        jsonResponse = jsonResponse.Replace("```json", "", StringComparison.OrdinalIgnoreCase)
                                                   .Replace("```", "")
                                                   .Replace("'''", "")
                                                   .Trim();
                    }
                    
                    using var doc = JsonDocument.Parse(jsonResponse);
                    if (doc.RootElement.TryGetProperty("TableName", out var tn)) tableName = tn.GetString() ?? tableName;
                    
                    if (doc.RootElement.TryGetProperty("Items", out var items))
                    {
                        foreach (var item in items.EnumerateArray())
                        {
                            string sym = item.GetProperty("Symbol").GetString() ?? "";
                            string per = item.GetProperty("Period").GetString() ?? "";
                            if (!string.IsNullOrEmpty(sym))
                                results.Add((sym, per));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.AI($"❌ ParseGuruTableFromImage Hatası: {ex.Message}");
                // Log raw response for debugging (truncated to avoid massive logs if image data somehow leaks, though improbable here)
                // We cannot access jsonResponse here easily because of scope, but the intent is clear.
                // Let's rely on the fix for now.
            }
            return (results, tableName);
        }

        public async Task<string?> GenerateGuruHonoringThread(string symbol, string period, string guruHandle, string originalTweetUrl, string tableName = "EFE HMA", string guruName = "Efelerin Efesi", string technicalContext = "", string? imagePath = null, PivotData? pivotData = null)
        {
            // 1) Geçmiş analiz hafızası (kendi önceki yorumların) – guru thread'ine referans için
            string pastContext = _memory.GetSymbolContext(symbol);

            // 2) Gösterge rehberi (IndicatorGuide) – derin teknik analiz için
            string indicatorContext = "";
            try
            {
                string indicatorGuidePath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Config", "IndicatorGuide.md");
                if (System.IO.File.Exists(indicatorGuidePath))
                {
                    indicatorContext = System.IO.File.ReadAllText(indicatorGuidePath);
                    indicatorContext = $@"=== GRAFİKTEKİ GÖSTERGE REHBERİ ===
{indicatorContext}
=== GÖSTERGE REHBERİ SONU ===";
                }
            }
            catch { /* indicator rehberi isteğe bağlı */ }

            // 2.5) Görselden otomatik gösterge çıkarımı (RSI/MACD/Pivot/Fibo/Divergence)
            try
            {
                if (!string.IsNullOrEmpty(imagePath) && File.Exists(imagePath))
                {
                    var extractor = new IndicatorExtractor(this, msg => Logger.AI(msg));
                    var ind = await extractor.ExtractIndicatorsFromScreenshot(imagePath);
                    if (!string.IsNullOrEmpty(ind.SummaryContext))
                    {
                        technicalContext += $"\n\nGÖSTERGE ÖZETİ (Otomatik):\n{ind.SummaryContext}";
                    }
                }
            }
            catch (Exception ex)
                Logger.AI($"⚠️ Guru analizinde gösterge çıkarma hatası: {ex.Message}");
            }

            // 3) Derin teknik analiz + guru onurlandırma + geçmiş analiz karşılaştırması
            // v3.8.3: Updated to use centralized PromptManager with Tevfik Dinçer Persona
            string prompt = _prompts.GetGuruHonoringThreadPrompt(
                symbol, 
                "Guru Analysis", // Strategy name fallback
                "N/A",           // Score not relevant here
                "N/A",           // Price context is embedded in technicalContext or not primary focus
                technicalContext, 
                guruName, 
                $"{guruName} (@{guruHandle}) - {tableName}" // Simple citation
            );

            if (!string.IsNullOrEmpty(imagePath) && File.Exists(imagePath))
            {
                byte[] imageBytes = File.ReadAllBytes(imagePath);
                string base64 = Convert.ToBase64String(imageBytes);
                return await SendMultimodalRequest(prompt, base64);
            }

            return await SendRequest(prompt);
        }
        /// <summary>
        /// HIVE Protocol Phase 1.5: Universal Wisdom Analysis
        /// Returns structured WisdomItem from AI analysis of any content (Tweets, Articles, etc.)
        /// </summary>
        public async Task<WisdomItem?> GenerateMetaAnalysisV2(string content, string author, string url)
        {
            try
            {
                var prompt = _prompts.GetUniversalWisdomPrompt(content, author);
                
                string? jsonResponse = null;
                if (ModelManager != null && ConfigManager.Current?.EnableMultiModel == true)
                {
                    jsonResponse = await ModelManager.SendRequest(XiDeAI_Pro.Services.AI.TaskType.MetaTeacherAnalysis, prompt);
                }
                else
                {
                    jsonResponse = await SendRequest(prompt, 0.7);
                }
                
                if (string.IsNullOrEmpty(jsonResponse)) return null;
                
                // Clean JSON from markdown formatting
                jsonResponse = jsonResponse.Replace("```json", "").Replace("```", "").Trim();
                int startIdx = jsonResponse.IndexOf('{');
                int endIdx = jsonResponse.LastIndexOf('}');
                if (startIdx >= 0 && endIdx > startIdx)
                {
                    jsonResponse = jsonResponse.Substring(startIdx, endIdx - startIdx + 1);
                }
                
                using var doc = JsonDocument.Parse(jsonResponse);
                var root = doc.RootElement;
                
                bool isValuable = root.TryGetProperty("is_valuable", out var valProp) && valProp.GetBoolean();
                
                if (!isValuable) return null; // Not worth storing
                
                return new WisdomItem
                {
                    Category = root.TryGetProperty("category", out var cat) ? cat.GetString() ?? "General" : "General",
                    Title = root.TryGetProperty("title", out var title) ? title.GetString() ?? "" : "",
                    Summary = root.TryGetProperty("summary", out var sum) ? sum.GetString() ?? "" : "",
                    ActionItem = root.TryGetProperty("action_item", out var act) ? act.GetString() ?? "" : "",
                    Priority = root.TryGetProperty("priority", out var pri) ? pri.GetString() ?? "MEDIUM" : "MEDIUM",
                    SourceAuthor = author,
                    SourceUrl = url,
                    LearnedAt = DateTime.Now
                };
            }
            catch (Exception ex) 
            { 
                Logger.AI($"⚠️ GenerateMetaAnalysisV2 JSON parse hatası: {ex.Message}");
                return null; 
            }
        }
        
        /// <summary>
        /// Legacy Meta-Teacher Analysis (returns plain text)
        /// </summary>
        [Obsolete("Use GenerateMetaAnalysisV2 for structured WisdomItem output")]
        public async Task<string?> GenerateMetaAnalysis(string content, string author, string url)
        {
            try
            {
                var prompt = $@"
SYSTEM: Sen XiDeAI'nın 'Council of AI' (Meta-Teacher) modülüsün.
Görevin: VIP finansal guruların paylaşımlarını analiz ederek sistemimiz için stratejik dersler çıkarmak.

YAZAR: {author}
İÇERİK: {content}

ANALİZ KRİTERLERİ:
1. Bu paylaşım genel bir piyasa psikolojisi dersi mi?
2. Teknik bir indikatör kullanımı veya yeni bir strateji mi öneriyor?
3. Sistemimizi geliştirmek için (tarama kriterleri, yeni hoca önerileri vb.) bir ipucu barındırıyor mu?

EĞER PAYLAŞIM ÇOK DEĞERLİYSE: Tek cümlede, ders niteliğinde bir 'Insight' oluştur.
EĞER PAYLAŞIM SIRADANSA: 'Sistem güncellemesi gerekmiyor' cevabını ver.

Ders Örneği: 'Yükselen trendlerde RSI aşırı alım bölgesinde olsa bile trendin devam edebileceğini unutmamak gerekir.'
";
                if (ModelManager != null && ConfigManager.Current?.EnableMultiModel == true)
                {
                    return await ModelManager.SendRequest(XiDeAI_Pro.Services.AI.TaskType.MetaTeacherAnalysis, prompt);
                }
                
                return await SendRequest(prompt, 0.7);
            }
            catch { return null; }
        }

        /// <summary>
        /// Yeni bir fenomenin "Guru" (Hoca) olmaya uygun olup olmadığını analiz eder.
        /// </summary>
        public async Task<bool> AnalyzePotentialGuru(string content, string author)
        {
            try
            {
                var prompt = $@"
Sen bir 'Hoca Kaşifi' yapay zekasın. 
Aşağıdaki paylaşımın sahibi olan @{author} kullanıcısının paylaştığı içerik, bir finansal guru (Hoca) kalitesinde mi?

İÇERİK: {content}

KRİTERLER:
- Paylaşım teknik analiz, piyasa stratejisi veya derin finansal bilgi içeriyor mu?
- Kişisel anı veya alakasız yorumlardan uzak mı?
- Başkalarına rehberlik edecek nitelikte mi?

CEVAP: Sadece 'EVET' veya 'HAYIR' cevabını ver. Başka açıklama yapma.
";
                string? response = null;
                if (ModelManager != null && ConfigManager.Current?.EnableMultiModel == true)
                {
                    response = await ModelManager.SendRequest(XiDeAI_Pro.Services.AI.TaskType.PotentialGuruAnalysis, prompt);
                }
                else
                {
                    response = await SendRequest(prompt, 0.3);
                }

                return (response ?? "").Trim().ToUpper().Contains("EVET");
            }
            catch { return false; }
        }



        public async Task<string?> AnalyzeNewsForThread(string title, string source, string link = "")
        {
            string prompt = GeneratePremiumNewsAnalysisPrompt(title, source, link);

            if (ModelManager != null && ConfigManager.Current?.EnableMultiModel == true)
            {
                return await ModelManager.SendRequest(XiDeAI_Pro.Services.AI.TaskType.NewsThreadGeneration, prompt);
            }

            return await SendRequest(prompt);
        }

        public async Task<string?> GeneratePerformanceSynthesis(DailyReport report)
        {
            var summaryData = new
            {
                report.TotalSignals,
                HitRate = report.TotalSignals > 0 ? (decimal)report.Winners / report.TotalSignals * 100 : 0,
                report.AvgReturn,
                report.MarketReturn,
                report.AvgAlpha,
                Strategies = report.StrategyStats.Select(s => new { s.Key, s.Value.WinRate, s.Value.TotalSignals })
            };

            string json = JsonSerializer.Serialize(summaryData);
            string prompt = _prompts.GetPerformanceReportPrompt(
                json, 
                report.BestPerformer?.Symbol ?? "N/A", 
                report.WorstPerformer?.Symbol ?? "N/A"
            );

            return await SendRequest(prompt);
        }

        private string GeneratePremiumNewsAnalysisPrompt(string title, string source, string link = "")
        {
            // Link varsa prompt'a ekle, yoksa sadece kaynak adını kullan
            string linkSection = !string.IsNullOrEmpty(link) 
                ? $"🔗 {link}" 
                : $"🔗 Kaynak: {source}";
            
            return $@"KİMLİK: Sen uzman bir Baş Ekonomist ve Stratejistsin. Piyasa tecrübeni profesyonel ama samimi bir dille yansıt.

GÖREV: Aşağıdaki haberi 2 tweet halinde analiz et. 

Piyasa Haberi: {title}
Kaynak: {source}
{linkSection}

=== TWEET 1 (Haber & Giriş) ===
🚨 [Haber Başlığı]
{source} kaynaklı haberi analiz ettim. Durum [ÖNEMLİ/KRİTİK]!
{linkSection}

#BIST100 #Haber #Borsa

=== TWEET 2 (Derin Analiz) ===
🧠 ANALİZ:
• [Haberin kısa ve net özeti]
• [Piyasa üzerindeki doğrudan etkileri]
• [Yatırımcıların dikkat etmesi gereken riskler]

⚠️ Y.T.D.

KURALLAR:
1. Tweetleri ||| ile ayır.
2. {linkSection} kısmını AYNEN TWEET 1'de kullan. KESİNLİKLE ""[Haber Linki Buraya Gelecek]"" gibi placeholder yazma.
3. KESİNLİKLE kendini tanıtma (yaş, isim vb.). Doğrudan habere odaklan.";
        }

        private string GenerateStandardNewsAnalysisPrompt(string title, string source)
        {
            return $@"Sen Deneyimli bir Baş Ekonomist ve Stratejist'sin. 
Aşağıdaki haberi küresel ve yerel piyasalar açısından derinlemesine analiz et.

Haber: {title}
Kaynak: {source}

GÖREVLER:
1. 🧠 **Analiz:** Haberin sadece ne olduğunu değil, **""İkinci Derece Etkilerini""** (Second-Order Effects) düşün. (Örn: Petrol artarsa -> Havayolları düşer -> Turizm etkilenir). Zincirleme reaksiyonları bul.
2. 🚨 **Etki Düzeyi:** Bu haber piyasalar (BIST, Döviz, Altın, Kripto) için YÜKSEK veya KRİTİK öneme sahip mi? Değilse 'NO_IMPACT' döndür.
3. #️⃣ **Hashtag:** Haberle ilgili en çok etkileşim alacak, spesifik ve akıllı MAKSİMUM 3 hashtag seç. (Sadece #Borsa deme, #TUPRS #Brent gibi spesifik ol).

ÇIKTI FORMATI (Sadece Tweet Metni):
🚨 PİYASA ALARMI: [Çarpıcı Başlık]

📰 [Haberin Özeti - 1 Cümle]

🧠 DERİN ANALİZ:
• [Doğrudan Etki]
• [Zincirleme/Dolaylı Etki - Kritik!]
• [Yatırımcı Ne Yapmalı?]

#Hashtag1 #Hashtag2 #Hashtag3 ...
⚠️ Yatırım tavsiyesi değildir.

NOT: Eğer etki düşükse sadece 'NO_IMPACT' yaz.";
        }

        public async Task<string?> GenerateGenericContent(string prompt)
        {
            if (ModelManager != null && ConfigManager.Current?.EnableMultiModel == true)
            {
                // v3.6.6: Default to GeneralAnalysis if no specific task provided
                return await ModelManager.SendRequest(XiDeAI_Pro.Services.AI.TaskType.GeneralAnalysis, prompt);
            }
            return await SendRequest(prompt);
        }

        // New overload for specific task types
        public async Task<string?> GenerateGenericContent(string prompt, XiDeAI_Pro.Services.AI.TaskType taskType)
        {
            if (ModelManager != null && ConfigManager.Current?.EnableMultiModel == true)
            {
                return await ModelManager.SendRequest(taskType, prompt);
            }
            return await SendRequest(prompt);
        }

        public async Task<string?> SendRequest(string prompt, double temperature = 0.5)
        {
            await _semaphore.WaitAsync(); // v3.5.2: Queue requests
            try 
            {
                // Wait 500ms between requests to avoid burst rate limits
                await Task.Delay(500).ConfigureAwait(false);

                if (ConfigManager.Current == null)
                {
                    LastError = "ConfigManager.Current is null";
                    Logger.Sys(LastError);
                    return null;
                }

                var apiKey = ConfigManager.Current.GeminiApiKey;
                if (string.IsNullOrEmpty(apiKey)) 
                {
                    LastError = "Gemini API Key eksik.";
                    return null;
                }

                var requestBody = new
                {
                    contents = new[]
                    {
                        new { parts = new[] { new { text = prompt } } }
                    },
                    generationConfig = new
                    {
                        temperature = temperature,
                        maxOutputTokens = 2048
                    }
                };

                string json = JsonSerializer.Serialize(requestBody);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                var model = !string.IsNullOrEmpty(ConfigManager.Current.GeminiModel) ? ConfigManager.Current.GeminiModel : "gemini-2.0-flash-exp";
                var url = $"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={apiKey}";
                
                var response = await client.PostAsync(url, content).ConfigureAwait(false);
                var responseContent = await response.Content.ReadAsStringAsync().ConfigureAwait(false);

                if (!response.IsSuccessStatusCode)
                {
                    if ((int)response.StatusCode == 429) // Too Many Requests
                    {
                        Logger.AI("⚠️ Gemini API 429 (Too Many Requests) hatası. 10 saniye bekleniyor...");
                        await Task.Delay(10000).ConfigureAwait(false);
                        
                        // Retry with backoff
                        response = await client.PostAsync(url, content).ConfigureAwait(false);
                        responseContent = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                        
                        if (!response.IsSuccessStatusCode)
                        {
                            LastError = $"Gemini 429 Retry Failed. Status: {response.StatusCode}";
                            Logger.AI($"❌ {LastError}");
                            return null;
                        }
                    }
                    else
                    {
                        LastError = $"Gemini API Error ({response.StatusCode}): {responseContent}";
                        Logger.AI($"❌ {LastError}");
                        return null;
                    }
                }
                
                // Parse JSON response
                string? result = null;
                using (JsonDocument jsonDoc = JsonDocument.Parse(responseContent))
                {
                    JsonElement root = jsonDoc.RootElement;
                    if (root.TryGetProperty("candidates", out var candidates) && candidates.GetArrayLength() > 0)
                    {
                        var firstCandidate = candidates[0];
                        if (firstCandidate.TryGetProperty("content", out var contentElement))
                        {
                            if (contentElement.TryGetProperty("parts", out var parts) && parts.GetArrayLength() > 0)
                            {
                                var firstPart = parts[0];
                                if (firstPart.TryGetProperty("text", out var text))
                                {
                                    result = text.GetString();
                                }
                            }
                        }
                    }
                }
                
                // OPTIMIZATION: Retry logic for empty responses (prevents API quota waste)
                if (string.IsNullOrWhiteSpace(result) || result == "null")
                {
                    Logger.AI("⚠️ Gemini boş yanıt döndü, 3 saniye sonra tekrar deneniyor...");
                    await Task.Delay(3000).ConfigureAwait(false);
                    
                    // Retry once
                    response = await client.PostAsync(url, content).ConfigureAwait(false);
                    responseContent = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                    
                    if (response.IsSuccessStatusCode)
                    {
                        using (JsonDocument jsonDoc = JsonDocument.Parse(responseContent))
                        {
                            JsonElement root = jsonDoc.RootElement;
                            if (root.TryGetProperty("candidates", out var candidates) && candidates.GetArrayLength() > 0)
                            {
                                var firstCandidate = candidates[0];
                                if (firstCandidate.TryGetProperty("content", out var contentElement2))
                                {
                                    if (contentElement2.TryGetProperty("parts", out var partsRetry) && partsRetry.GetArrayLength() > 0)
                                    {
                                        var firstPart = partsRetry[0];
                                        if (firstPart.TryGetProperty("text", out var text))
                                        {
                                            result = text.GetString();
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    if (string.IsNullOrWhiteSpace(result))
                    {
                        // Check for Safety Block or other feedback
                        string failReason = "Gemini returned empty response.";
                        try {
                            using (JsonDocument checkDoc = JsonDocument.Parse(responseContent)) {
                                if (checkDoc.RootElement.TryGetProperty("promptFeedback", out var feedback)) {
                                    if (feedback.TryGetProperty("blockReason", out var reason)) {
                                        failReason = $"Gemini BLOCKED: {reason.GetString()}";
                                    }
                                }
                            }
                        } catch {}

                        LastError = failReason;
                        Logger.AI($"❌ {LastError}");
                    }
                    else
                    {
                        Logger.AI("✅ Gemini 2. denemede başarılı yanıt aldı");
                    }
                }
                
                return result;
            }
            catch (Exception ex)
            {
                LastError = ex.Message;
                Logger.AI($"❌ Gemini Exception: {ex.Message}");
            }
            finally
            {
                _semaphore.Release();
            }
            return null;
        }

        public async Task<List<string>> GetAvailableModels(string apiKey)
        {
            try
            {
                var url = $"https://generativelanguage.googleapis.com/v1beta/models?key={apiKey}";
                var response = await client.GetAsync(url);
                var json = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode)
                {
                    using (JsonDocument doc = JsonDocument.Parse(json))
                    {
                        if (doc.RootElement.TryGetProperty("models", out var modelsElement))
                        {
                            var models = new List<string>();
                            foreach (var model in modelsElement.EnumerateArray())
                            {
                                var name = model.GetProperty("name").GetString();
                                if (name != null)
                                {
                                    models.Add(name.Replace("models/", ""));
                                }
                            }
                            // Filter for gemini models
                            return models.Where(m => m.ToLower().Contains("gemini")).ToList();
                        }
                    }
                }
                else
                {
                    LastError = $"HTTP {(int)response.StatusCode}: {json}";
                }
            }
            catch (Exception ex)
            {
                LastError = ex.Message;
            }
            return new List<string>();
        }

        /// <summary>
        /// Send multimodal request (text + image) to Gemini
        /// </summary>
        public async Task<string?> SendMultimodalRequest(string prompt, string imageBase64)
        {
            await _semaphore.WaitAsync();
            try
            {
                // Wait 500ms between requests to avoid burst rate limits
                await Task.Delay(500).ConfigureAwait(false);

                if (ConfigManager.Current == null)
                {
                    LastError = "ConfigManager.Current is null";
                    return null;
                }

                var apiKey = ConfigManager.Current.GeminiApiKey;
                if (string.IsNullOrEmpty(apiKey)) 
                {
                    LastError = "Gemini API Key eksik.";
                    return null;
                }

                var requestBody = new
                {
                    contents = new[]
                    {
                        new { 
                            parts = new object[] { 
                                new { text = prompt },
                                new { 
                                    inline_data = new {
                                        mime_type = "image/png",
                                        data = imageBase64
                                    }
                                }
                            } 
                        }
                    }
                };

                string json = JsonSerializer.Serialize(requestBody);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                var model = !string.IsNullOrEmpty(ConfigManager.Current.GeminiModel) ? ConfigManager.Current.GeminiModel : "gemini-2.0-flash-exp";
                var url = $"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={apiKey}";
                
                var response = await client.PostAsync(url, content).ConfigureAwait(false);
                var resultJson = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                
                if (!response.IsSuccessStatusCode && (int)response.StatusCode == 429)
                {
                    Logger.AI("⚠️ Gemini Multimodal 429 hatası. 10 saniye bekleniyor...");
                    await Task.Delay(10000).ConfigureAwait(false);
                    response = await client.PostAsync(url, content).ConfigureAwait(false);
                    resultJson = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                }

                if (response.IsSuccessStatusCode)
                {
                    using (JsonDocument doc = JsonDocument.Parse(resultJson))
                    {
                        var candidates = doc.RootElement.GetProperty("candidates");
                        if (candidates.GetArrayLength() > 0)
                        {
                            var text = candidates[0]
                                      .GetProperty("content")
                                      .GetProperty("parts")[0]
                                      .GetProperty("text").GetString();
                             return text;
                        }
                    }
                }
                else
                {
                    LastError = $"HTTP {(int)response.StatusCode}: {resultJson}";
                    Logger.AI($"❌ Gemini Multimodal API Error: {LastError}");
                }
            }
            catch (Exception ex)
            {
                Logger.AI($"❌ Gemini Multimodal Exception: {ex.Message}");
            }
            finally
            {
                _semaphore.Release();
            }
            return null;
        }

        /// <summary>
        /// Generate market analysis WITH visual chart analysis
        /// </summary>
        public async Task<string?> GenerateMarketAnalysisWithChart(string symbol, string marketType, string priceContext, string screenshotPath, string influencerCitations = "")
        {
            try
            {
                // Convert screenshot to base64
                if (!System.IO.File.Exists(screenshotPath))
                {
                    Console.WriteLine($"Screenshot not found: {screenshotPath}");
                    // Fallback to text-only analysis
                    return await GenerateMarketAnalysisWithPrice(symbol, marketType, priceContext, influencerCitations);
                }

                byte[] imageBytes = System.IO.File.ReadAllBytes(screenshotPath);
                string imageBase64 = Convert.ToBase64String(imageBytes);

                // Load indicator guide if exists
                string indicatorContext = "";
                try
                {
                    string indicatorGuidePath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Config", "IndicatorGuide.md");
                    if (System.IO.File.Exists(indicatorGuidePath))
                    {
                        indicatorContext = System.IO.File.ReadAllText(indicatorGuidePath);
                        indicatorContext = $@"
=== GRAFİKTEKİ GÖSTERGE REHBERİ ===
{indicatorContext}
=== GÖSTERGE REHBERİ SONU ===

";
                    }
                }
                catch { /* Indicator guide optional */ }

                // Build influencer section if provided
                string influencerSection = string.IsNullOrEmpty(influencerCitations)
                    ? ""
                    : $@"

PİYASA GÖRÜŞÜ (Sosyal Medya Fenomen Analizi):
{influencerCitations}
(Bu görüşleri kendi grafiksel analizinle harmanla ve dengeli yaz)";

                // USE NEW CENTRALIZED PROMPT (Formations + Smart Money)
                string prompt = _prompts.GetDeepTechnicalAnalysisPrompt(symbol, marketType, priceContext, indicatorContext, influencerCitations);

                return await SendMultimodalRequest(prompt, imageBase64);
            }
            catch (Exception ex)
            {
                Logger.AI($"⚠️ Error in GenerateMarketAnalysisWithChart: {ex.Message}");
                // Fallback to text-only
                return await GenerateMarketAnalysisWithPrice(symbol, marketType, priceContext, influencerCitations);
            }
        }

        /// <summary>
        /// Get the model name from config or use default
        /// </summary>
        private string GetSelectedModel()
        {
            var model = ConfigManager.Current.GeminiModel;
            return string.IsNullOrEmpty(model) ? "gemini-2.0-flash-exp" : model;
        }

        /// <summary>
        /// Get list of available Gemini models for the given API key
        /// </summary>
        public async Task<List<string>> GetAvailableModelsAsync()
        {
            var apiKey = ConfigManager.Current.GeminiApiKey;
            if (string.IsNullOrEmpty(apiKey))
            {
                LastError = "API Key boş";
                return new List<string>();
            }

            try
            {
                var url = $"https://generativelanguage.googleapis.com/v1beta/models?key={apiKey}";
                var response = await client.GetStringAsync(url);
                
                using var doc = JsonDocument.Parse(response);
                var models = new List<string>();
                
                if (doc.RootElement.TryGetProperty("models", out var modelsArray))
                {
                    foreach (var model in modelsArray.EnumerateArray())
                    {
                        var name = model.GetProperty("name").GetString()?.Replace("models/", "");
                        if (name != null && name.Contains("gemini"))
                        {
                            models.Add(name);
                        }
                    }
                }
                
                return models;
            }
            catch (Exception ex)
            {
                LastError = $"Model listesi alınamadı: {ex.Message}";
                return new List<string>();
            }
        }

        /// <summary>
        /// Test connection to Gemini API with a simple prompt
        /// </summary>
        public async Task<(bool Success, string Message)> TestConnectionAsync()
        {
            var apiKey = ConfigManager.Current.GeminiApiKey;
            if (string.IsNullOrEmpty(apiKey))
            {
                return (false, "API Key girilmemiş!");
            }

            try
            {
                var model = GetSelectedModel();
                var testPrompt = "Merhaba! Bu bir API bağlantı testidir. Sadece 'Bağlantı başarılı!' yaz.";
                
                var requestBody = new
                {
                    contents = new[]
                    {
                        new { parts = new[] { new { text = testPrompt } } }
                    }
                };

                string json = JsonSerializer.Serialize(requestBody);
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                
                var url = $"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={apiKey}";
                var response = await client.PostAsync(url, content);
                
                if (response.IsSuccessStatusCode)
                {
                    var result = await response.Content.ReadAsStringAsync();
                    using var doc = JsonDocument.Parse(result);
                    var text = doc.RootElement
                        .GetProperty("candidates")[0]
                        .GetProperty("content")
                        .GetProperty("parts")[0]
                        .GetProperty("text").GetString();
                    
                    return (true, $"✅ Bağlantı başarılı!\nModel: {model}\nYanıt: {text?.Substring(0, Math.Min(text.Length, 100))}");
                }
                else
                {
                    var error = await response.Content.ReadAsStringAsync();
                    return (false, $"❌ API Hatası ({(int)response.StatusCode}): {error.Substring(0, Math.Min(error.Length, 200))}");
                }
            }
            catch (Exception ex)
            {
                return (false, $"❌ Bağlantı hatası: {ex.Message}");
            }
        }

        public async Task<string?> SynthesizeInfluencerAnalyses(string symbol, string marketType, string priceContext, string visualAnalysis, List<InfluencerPost> influencerPosts)
        {
            // Ensure list is not null
            influencerPosts = influencerPosts ?? new List<InfluencerPost>();

            var influencerContext = "";
            if (influencerPosts.Count == 0)
            {
                influencerContext = "Henüz kayda değer influencer yorumu bulunamadı. (Nötr/Belirsiz Sentiment)";
            }
            else
            {
                for (int i = 0; i < influencerPosts.Count; i++)
                {
                    var post = influencerPosts[i];
                    influencerContext += $"\n{i + 1}. @{post.Handle}: \"{CleanTweetContent(post.Content)}\"\n   (Etkileşim: {post.Engagement})\n";
                }
            }
            
            // Geçmiş analiz kontrolü (priceContext içinde geliyorsa parse et)
            string historyNote = "";
            if (priceContext.Contains("GEÇMİŞ ANALİZ:"))
            {
                var parts = priceContext.Split(new[] { "GEÇMİŞ ANALİZ:" }, StringSplitOptions.None);
                if (parts.Length > 1)
                {
                    historyNote = "\n\n📜 GEÇMİŞ DEĞERLENDİRME:\n" + parts[1].Trim();
                    priceContext = parts[0].Trim();
                }
            }

            string prompt = _prompts.GetSignalSynthesisPrompt(symbol, priceContext, visualAnalysis, influencerContext, historyNote);
            return await SendRequest(prompt);
        }





        public async Task<string?> GenerateMotivationTweet()
        {
            string prompt = _prompts.GetMotivationPrompt();
            return await SendRequest(prompt);
        }

        public async Task<string?> GenerateCloseSummary(string marketData)
        {
            string prompt = $@"Sen profesyonel, samimi bir borsa yorumcususun.
GÖREV: BIST100 kapanışı itibariyle verileri yorumla ve 'Günü Bitirirken' tweeti at.

VERİLER:
{marketData}

KURALLAR:
1. Piyasaların kapandığını belirt.
2. Verilen rakamları (BIST, Dolar, Altın) kısaca özetle (yükseldi/düştü/sakin gibi yorumla).
3. Genel bir değerlendirme yap (Boğa/Ayı/Nötr).
4. 'Yarın yeni fırsatlar' mesajı ver.
5. #BIST100 #Borsa #Altın #Dolar hashtaglerini ekle.
6. Maksimum 280 karakter.
7. ASLA '[...]' gibi placeholder/şablon kullanma! Sadece tam cümleler kur.
8. Veri yoksa 'Piyasa verileri karışık' de.";

            return await SendRequest(prompt);
        }

        public async Task<string?> GenerateReply(string tweetContent, string authorHandle)
        {
            string prompt = _prompts.GetReplyPrompt(tweetContent, authorHandle);
            return await SendRequest(prompt);
        }

        public async Task<string?> GenerateMarketCloseTableTweet(string indicesData, string topGainers, string topLosers, string topVolume)
        {
            string prompt = _prompts.GetMarketClosePrompt(indicesData, topGainers, topLosers, topVolume);
            return await SendRequest(prompt);
        }

        private string CleanTweetContent(string raw)
        {
            if (string.IsNullOrEmpty(raw)) return "";
            raw = System.Text.RegularExpressions.Regex.Replace(raw, @"http[s]?://\S+", "");
            raw = raw.Trim();
            if (raw.Length > 200) raw = raw.Substring(0, 200) + "...";
            return raw;
        }

    }
}


