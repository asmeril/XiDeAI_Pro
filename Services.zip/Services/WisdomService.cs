using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace XiDeAI_Pro.Services
{
    /// <summary>
    /// Represents a piece of knowledge/technique learned from the Council (Meta-Teacher).
    /// </summary>
    public class WisdomItem
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        
        /// <summary>
        /// Category: TECH, FINANCE, BUSINESS, PERSONAL, GLOBAL
        /// </summary>
        public string Category { get; set; } = "FINANCE";
        
        public string Title { get; set; } = "";
        public string Summary { get; set; } = "";
        
        /// <summary>
        /// Suggested action item for the developer (e.g., "Add Chain of Thought to news analysis prompt")
        /// </summary>
        public string ActionItem { get; set; } = "";
        
        /// <summary>
        /// Priority: LOW, MEDIUM, HIGH
        /// </summary>
        public string Priority { get; set; } = "MEDIUM";
        
        /// <summary>
        /// The Twitter handle of the source (e.g., @hrrcnes)
        /// </summary>
        public string SourceAuthor { get; set; } = "";
        
        /// <summary>
        /// Original tweet URL
        /// </summary>
        public string SourceUrl { get; set; } = "";
        
        /// <summary>
        /// When this insight was learned
        /// </summary>
        public DateTime LearnedAt { get; set; } = DateTime.Now;
        
        /// <summary>
        /// User marks this true when they've implemented the suggestion
        /// </summary>
        public bool IsImplemented { get; set; } = false;
    }

    /// <summary>
    /// HIVE PROTOCOL - Phase 1: Wisdom Persistence Service
    /// Manages the "learned wisdom" from Meta-Teacher (Council of AI).
    /// Stores insights extracted from @hrrcnes, @DataChaz, @TansuYegen, @AndrewYNg.
    /// </summary>
    public class WisdomService
    {
        private readonly string _storagePath;
        private List<WisdomItem> _wisdom = new List<WisdomItem>();
        private readonly Action<string>? _logger;

        public WisdomService(Action<string>? logger = null)
        {
            _logger = logger;
            string appData = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "XiDeAI"
            );
            Directory.CreateDirectory(appData);
            _storagePath = Path.Combine(appData, "Wisdom.json");
            Load();
        }

        /// <summary>
        /// Add a new insight to the wisdom database.
        /// </summary>
        public void AddInsight(WisdomItem item)
        {
            // Check for duplicates based on similar title (fuzzy match)
            bool exists = _wisdom.Any(w => 
                w.Title.Equals(item.Title, StringComparison.OrdinalIgnoreCase) ||
                (w.SourceUrl == item.SourceUrl && !string.IsNullOrEmpty(item.SourceUrl))
            );

            if (exists)
            {
                Log($"⚠️ Wisdom zaten mevcut: {item.Title}");
                return;
            }

            _wisdom.Add(item);
            Save();
            Log($"🧠 Yeni Bilgelik Eklendi: [{item.Category}] {item.Title} (Öncelik: {item.Priority})");
        }

        /// <summary>
        /// Get all wisdom entries.
        /// </summary>
        public List<WisdomItem> GetAllInsights() => _wisdom.OrderByDescending(w => w.LearnedAt).ToList();

        /// <summary>
        /// Get wisdom entries filtered by category.
        /// </summary>
        public List<WisdomItem> GetInsightsByCategory(string category)
        {
            return _wisdom
                .Where(w => w.Category.Equals(category, StringComparison.OrdinalIgnoreCase))
                .OrderByDescending(w => w.LearnedAt)
                .ToList();
        }

        /// <summary>
        /// Get only high-priority, unimplemented insights.
        /// </summary>
        public List<WisdomItem> GetActionableInsights()
        {
            return _wisdom
                .Where(w => !w.IsImplemented && w.Priority == "HIGH")
                .OrderByDescending(w => w.LearnedAt)
                .ToList();
        }

        /// <summary>
        /// Mark an insight as implemented.
        /// </summary>
        public void MarkAsImplemented(string id)
        {
            var item = _wisdom.FirstOrDefault(w => w.Id == id);
            if (item != null)
            {
                item.IsImplemented = true;
                Save();
                Log($"✅ Bilgelik Uygulandı: {item.Title}");
            }
        }

        /// <summary>
        /// Get statistics about wisdom.
        /// </summary>
        public (int Total, int Implemented, int HighPriority) GetStats()
        {
            return (
                _wisdom.Count,
                _wisdom.Count(w => w.IsImplemented),
                _wisdom.Count(w => w.Priority == "HIGH" && !w.IsImplemented)
            );
        }

        private void Save()
        {
            try
            {
                var options = new JsonSerializerOptions { WriteIndented = true };
                string json = JsonSerializer.Serialize(_wisdom, options);
                File.WriteAllText(_storagePath, json);
            }
            catch (Exception ex)
            {
                Log($"❌ Wisdom kayıt hatası: {ex.Message}");
            }
        }

        private void Load()
        {
            try
            {
                if (File.Exists(_storagePath))
                {
                    string json = File.ReadAllText(_storagePath);
                    _wisdom = JsonSerializer.Deserialize<List<WisdomItem>>(json) ?? new List<WisdomItem>();
                    Log($"📚 {_wisdom.Count} adet bilgelik yüklendi.");
                }
            }
            catch (Exception ex)
            {
                Log($"⚠️ Wisdom yükleme hatası: {ex.Message}");
                _wisdom = new List<WisdomItem>();
            }
        }

        private void Log(string message)
        {
            _logger?.Invoke(message);
        }
    }
}
