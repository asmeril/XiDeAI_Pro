using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace XiDeAI_Pro.Services
{
    public class OracleMarket
    {
        public string question { get; set; } = "";
        public string prediction { get; set; } = "";
        public double volume { get; set; }
        public string url { get; set; } = "";
    }

    public class OracleData
    {
        public string timestamp { get; set; } = "";
        public List<OracleMarket> markets { get; set; } = new List<OracleMarket>();
    }

    public class OracleService
    {
        private readonly string _scriptsPath;
        private readonly GeminiService _gemini;
        private readonly WisdomService _wisdom;
        private readonly Action<string> _logger;
        private OracleData _data = new OracleData();
        public string LastReport { get; private set; } = "Henüz Oracle öngörüsü yapılmadı.";

        public OracleService(string scriptsPath, GeminiService gemini, WisdomService wisdom, Action<string>? logger = null)
        {
            _scriptsPath = scriptsPath;
            _gemini = gemini;
            _wisdom = wisdom;
            _logger = logger ?? (_ => { });
        }

        private void Log(string msg) => _logger?.Invoke(msg);

        public async Task RefreshAsync()
        {
            Log("🔮 [ORACLE] Tahmin piyasaları taranıyor (Polymarket)...");
            try
            {
                string scriptFile = Path.Combine(_scriptsPath, "oracle.py");
                if (!File.Exists(scriptFile)) return;

                var psi = new ProcessStartInfo
                {
                    FileName = "python",
                    Arguments = $"\"{scriptFile}\"",
                    RedirectStandardOutput = true,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    StandardOutputEncoding = Encoding.UTF8
                };

                using var process = Process.Start(psi);
                if (process == null) return;

                string output = await process.StandardOutput.ReadToEndAsync();
                await process.WaitForExitAsync();

                if (!string.IsNullOrEmpty(output))
                {
                    var result = JsonSerializer.Deserialize<OracleData>(output);
                    if (result != null)
                    {
                        _data = result;
                        Log($"✅ [ORACLE] Veri alındı. {_data.markets.Count} aktif pazar inceleniyor.");
                    }
                }
            }
            catch (Exception ex)
            {
                Log($"❌ [ORACLE] Hata: {ex.Message}");
            }
        }

        public async Task<string> GenerateForesightReportAsync()
        {
            if (_data.markets.Count == 0) return "Henüz tahmin verisi toplanmadı.";

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("🔮 KAHİN (ORACLE) GELECEK ÖNGÖRÜSÜ");
            sb.AppendLine($"📅 {DateTime.Now:dd.MM.yyyy HH:mm}");
            sb.AppendLine();
            
            foreach (var m in _data.markets)
            {
                sb.AppendLine($"❓ {m.question}");
                sb.AppendLine($"👉 Mevcut Tahmin: {m.prediction}");
                sb.AppendLine($"🔗 {m.url}");
                sb.AppendLine();
            }

            string prompt = "Aşağıdaki tahmin piyasası verilerini (Dünya neye bahse giriyor?) analiz et.\n" +
                            "Bu olasılıklardan yola çıkarak, teknoloji dünyasını veya finansal piyasaları sarsabilecek 3 olası senaryo kurgula.\n" +
                            "Hangi olay 'kara kuğu' (beklenmedik ama yıkıcı) riski taşıyor? Profesyonel ve vizyoner bir dil kullan.\n\n" +
                            $"VERİLER:\n{sb.ToString()}";

            Log("🤖 [ORACLE] Gelecek simülasyonu başlatılıyor...");
            string analysis = await _gemini.GenerateGenericContent(prompt);
            LastReport = analysis;

            if (string.IsNullOrEmpty(analysis))
            {
                return $"Analiz başarısız. (Hata: {_gemini.LastError})";
            }

            // Save to Wisdom (GLOBAL Category)
            var wisdomItem = new WisdomItem
            {
                Category = "GLOBAL",
                Title = $"Oracle Gelecek Öngörüsü ({DateTime.Now:dd.MM})",
                Summary = analysis + "\n\n" + sb.ToString(),
                SourceAuthor = "Oracle (Polymarket)",
                SourceUrl = "Internal/Oracle",
                Priority = "HIGH",
                ActionItem = "Olası senaryolara karşı stratejik konumlanmayı gözden geçir."
            };

            _wisdom?.AddInsight(wisdomItem);
            Log("🧠 [ORACLE->WISDOM] Kahin raporu kaydedildi.");

            return analysis;
        }
    }
}
